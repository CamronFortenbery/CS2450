package com.example.cardmatch;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.widget.Button;
import android.widget.GridLayout;

import androidx.annotation.RequiresApi;
import androidx.appcompat.widget.AppCompatDrawableManager;

public class Cards extends Button {
    protected int rows;
    protected int columns;
    protected int cardFace;
    protected boolean matchFlag = false;
    protected boolean flippedFlag = false;

    protected Drawable cardFront;
    protected Drawable cardBack;

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    public Cards(Context context, int r, int c, int cardFaceId)
    {
        super(context);
        rows = r;
        columns = c;
        cardFace = cardFaceId;

        cardFront = AppCompatDrawableManager.get().getDrawable(context, cardFace);
        cardBack = AppCompatDrawableManager.get().getDrawable(context, R.drawable.cardback);

        setBackground(cardBack);
        GridLayout.LayoutParams parameters = new GridLayout.LayoutParams(GridLayout.spec(r), GridLayout.spec(c));
        parameters.width = (int) getResources().getDisplayMetrics().density*102;
        parameters.height = (int) getResources().getDisplayMetrics().density*102;
        setLayoutParams(parameters);

    }

    public boolean isMatchFlag()
    {
        return matchFlag;
    }

    public void setMatchFlag(boolean match)
    {
        matchFlag = match;
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    public void flip()
    {
        if(matchFlag)
        {
            return;
        }
        else if(flippedFlag)
        {
            setBackground(cardBack);
            flippedFlag = false;
        }
        else
        {
            setBackground(cardFront);
            flippedFlag = true;
        }
    }

    public int getCardFace()
    {
        return cardFace;
    }

}

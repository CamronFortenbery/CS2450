package com.example.matchcard;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.GridLayout;

import java.util.Random;

public class Game2x2 extends AppCompatActivity implements View.OnClickListener{

    private int numberOfElements;
    private Cards[] cards;
    private int[] cardImagePos;
    private int[] images;
    public int score;
    private boolean chosen;
    private Cards first;
    private Cards second;

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR1)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game2x2);

        GridLayout grid = (GridLayout)findViewById(R.id.grid_layout_2x3);
        int numOfRows = grid.getRowCount();
        int numofCols = grid.getColumnCount();
        score = 0;

        numberOfElements = numOfRows*numofCols;
        cards = new Cards[numberOfElements];
        images = new int[numberOfElements/2];

        images[0] = R.drawable.cap;
        images[1] = R.drawable.gamora;
        images[2] = R.drawable.groot;
        images[3] = R.drawable.hulk;
        images[4] = R.drawable.ironman;
        images[5] = R.drawable.nick;

        cardImagePos = new int[numberOfElements];
        shuffleImagePositions();
        for(int row = 0; row < numOfRows; row++)
        {
            for(int col = 0; col < numofCols; col++)
            {
                Cards tempC = new Cards(this, row, col, images[cardImagePos[row*numofCols+col]]);
                tempC.setId(View.generateViewId());
                tempC.setOnClickListener(this);
                cards[row*numofCols+col] = tempC;
                grid.addView(tempC);
            }
        }
    }

    protected void shuffleImagePositions()
    {
        Random rand = new Random();
        for(int a = 0; a < numberOfElements; a++)
        {
            cardImagePos[a]= a%(numberOfElements/2);
        }
        for(int b = 0; b < numberOfElements; b++)
        {
            int temp = cardImagePos[b];
            int swap = rand.nextInt(6);
            cardImagePos[b] = cardImagePos[swap];
            cardImagePos[swap] = temp;
        }

    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public void onClick(View v) {
        if(chosen)
        {
            return;
        }
        Cards card = (Cards) v;
        if(card.matchFlag)
        {
            return;
        }
        if(first == null)
        {
            first = card;
            first.flip();
            return;
        }
        if(first.getId() == card.getId())
        {
            return;
        }
        if(first.getCardFace() == card.getCardFace())
        {
            score += 2;
            card.flip();
            card.setMatchFlag(true);
            first.setEnabled(false);
            card.setEnabled(false);
            first.setMatchFlag(true);
            return;
        }
        else
        {
            second = card;
            second.flip();
            chosen = true;
            score -= 1;
            final Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run()
                {
                    first.flip();
                    first = null;
                    second.flip();
                    second = null;
                    chosen = false;
                }
            },500);
            return;
        }
    }
}

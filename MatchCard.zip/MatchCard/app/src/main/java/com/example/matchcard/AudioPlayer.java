package com.example.matchcard;

import android.content.Context;
import android.media.MediaPlayer;

public class AudioPlayer extends MediaPlayer {
    private MediaPlayer mPlayer;

    public void stop()
    {
        if(mPlayer != null)
        {
            mPlayer.release();
            mPlayer = null;
        }
    }

    public void play(Context c)
    {
        mPlayer.stop();
        mPlayer = MediaPlayer.create(c,R.raw.sunflower);
        mPlayer.start();
    }
}